const electron = require('electron');
const app = electron.app;
const BrowserWindow = electron.BrowserWindow;

var path = require('path');
const url = require('url');
const isDev = require('electron-is-dev');

let mainWindow
let secondWindow

function createWindow() {
	mainWindow = new BrowserWindow({
		minHeight: 150,
		minWidth: 1025,
		height: 150,
		width: 1025,
		maxWidth: 1025,
		maxHeight: 150,
		maximizable: false,
	})

	mainWindow.loadURL(isDev ? 'http://localhost:3000' : `file://${__dirname}/index.html`);


	mainWindow.on('closed', function() {
		mainWindow = null
	})

	app.on('ready', createWindow);

	app.on('window-all-closed', function() {
		if (process.platform !== 'darwin') {
			app.quit();
		}
	});

	app.on('activate', function() {
		if (mainWindow === null) {
			createWindow()
		}
	});}
